﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography.X509Certificates;

namespace MedicalLoginSystem
{
    public class Cart
    {
        private static List<Service> items = new List<Service>();
            public static decimal totalPrice = items.Sum(item => item.Price);

        public static void ViewCart()
        {
            if (items.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Your cart is empty. ");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(" Your cart contains: \n");
            
        Console.ResetColor();

            int i = 1;
            foreach (var service in items)
            {
                Console.WriteLine($"{i++}. {service.Name} - {service.Price:C}");
            }

            Console.ResetColor();
            Console.WriteLine("\n Would you like to proceed with your order? ");
            
            Console.Write("(");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Y");
            Console.ResetColor();
            Console.Write("/");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("N");
            Console.ResetColor();
            Console.Write("): ");

            switch (Console.ReadLine()?.ToUpper())
            {
                case "Y":

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" Proceeding with your order...");
                    Console.ResetColor();

                    totalPrice = Discounts.ApplyFidelityPointsDiscount(totalPrice);

                    break;

                case "N":
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Order cancelled.");
                    Console.ResetColor();
                    break;

                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Invalid choice. Returning to main menu.");
                    Console.ResetColor();
                    Thread.Sleep(2000);
                    Console.Clear();
                    break;
            }
        }

        public void AddToCart(Service service)
        {
            items.Add(service);
        }
    }
}