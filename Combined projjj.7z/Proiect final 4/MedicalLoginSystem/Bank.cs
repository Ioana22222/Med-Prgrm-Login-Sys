﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalLoginSystemConsole.Models
{
    public class Bank
    {
        public decimal Balance { get; private set; }

        public Bank(decimal startingBalance = 10000m)
        {
            Balance = startingBalance;
        }

        public void Deduct(decimal amount)
        {
            if (amount > Balance)
                throw new InvalidOperationException("Insufficient funds.");
            Balance -= amount;
        }

        public void Add(decimal amount)
        {
            Balance += amount;
        }

        public override string ToString()
        {
            return $"Balance: ${Balance:0.00}";
        }
    }
}
//nu bagati in seama :) 