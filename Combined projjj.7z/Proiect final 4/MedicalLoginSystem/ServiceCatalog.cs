using System;
using System.Collections.Generic;
using System.IO;

namespace MedicalLoginSystem
{
    internal static class ServiceCatalog
    {
        public static List<Service> LoadServices()
        {
            var services = new List<Service>();
            if (!File.Exists("Services.txt")) return services;
            foreach (var line in File.ReadAllLines("Services.txt"))
            {
                try
                {
                    services.Add(Service.FromString(line));
                }
                catch
                {
                    
                }
            }
            return services;
        }
    }
}