﻿using MedicalLoginSystem; 
using MedicalLoginSystemConsole.Services; 
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using MedicalLoginSystem;
using System.Runtime.CompilerServices;

namespace Proiect
{
    internal class Manager
    {
        public static List<MedicalLoginSystemConsole.Models.User> users = new List<MedicalLoginSystemConsole.Models.User>();
        static Dictionary<string, int> services = new Dictionary<string, int>();
        static List<Service> LoadServices()
        {
            var list = new List<Service>();
            if (!File.Exists("Services.txt")) return list;
            foreach (var line in File.ReadAllLines("Services.txt"))
            {
                try { list.Add(Service.FromString(line)); }
                catch { }
            }
            return list;
        }

        static void SaveServices(List<Service> services)
        {
            File.WriteAllLines("Services.txt", services.Select(s => s.ToString()));
        }


        public static void ShowManagerMenu()
        {

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n ============= Manager Menu ============= ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" 1 - Add users: ");
            Console.WriteLine(" 2 - Remove users: ");
            Console.WriteLine(" 3 - List users: ");
            Console.WriteLine(" 4 - Add Services: ");
            Console.WriteLine(" 5 - Change price of a service: ");
            Console.WriteLine(" 6 - Remove service: ");
            Console.WriteLine(" 7 - Show services: ");
            Console.WriteLine(" 8 - Change number of fidelity points: ");
            Console.WriteLine("\n 0 - Go back Register/Login menu\n");
            Console.ResetColor();
        }
        public static void ChooseManagerOptions()
        {
        options:
            Console.WriteLine("\n Select your option");
            string opt = Console.ReadLine();
            switch (opt)
            {
                case "1":
                    AddUsers();
                    break;

                case "2":
                    ListUsers();
                    break;

                case "3":
                    RemoveUsers();
                    break;

                case "4":
                    AddServices();
                    break;

                case "5":
                    ChangePriceOfService();
                    break;

                case "6":
                    RemoveService();
                    break;

                case "7":
                    ShowServices();
                    break;

                case "8":
                    FidPointsMan();
                    break;

                case "0":
                    Console.Clear();
                    UserManager.StartProgram();
                    break;

                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Choose 1-8");
                    Console.ResetColor();
                    goto options;


            }

            static void AddUsers()
            {
                UserManager.Register();
            }

            static void RemoveUsers()
            {
                var filePath = "Users.txt";
                if (!File.Exists(filePath))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" No users found.");
                    Console.ResetColor();
                    return;
                }

                var lines = File.ReadAllLines(filePath).ToList();
                if (lines.Count == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" No users to remove.");
                    Console.ResetColor();
                    return;
                }


                Console.WriteLine(" Users:");
                for (int i = 0; i < lines.Count; i++)
                {
                    try
                    {
                        var user = System.Text.Json.JsonSerializer.Deserialize<MedicalLoginSystemConsole.Models.User>(lines[i]);
                        if (user != null)
                            Console.WriteLine($"{i + 1}. {user.Email} - {user.Name}");
                    }
                    catch
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"{i + 1}. [Invalid user data]");
                        Console.ResetColor();
                    }
                }

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write(" Enter the number of the user to remove: "); Console.ResetColor();
                if (int.TryParse(Console.ReadLine(), out int idx) && idx > 0 && idx <= lines.Count)
                {
                    lines.RemoveAt(idx - 1);
                    File.WriteAllLines(filePath, lines);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" User removed.");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Invalid selection.");
                    Console.ResetColor();
                }
            }
        }

        public static void LoadUsers()
        {
            var filePath = "Users.txt";
            var lines = File.ReadAllLines(filePath);
            for (int i = 0; i < lines.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(lines[i])) continue;
                var user = System.Text.Json.JsonSerializer.Deserialize<MedicalLoginSystemConsole.Models.User>(lines[i]);
                users.Add(user);
            }
        }

        static void ListUsers()
        {
            var filePath = "Users.txt";
            if (!File.Exists(filePath))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" No users found.");
                Console.ResetColor();
                return;
            }

            var lines = File.ReadAllLines(filePath);
            if (lines.Length == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" No users to display.");
                Console.ResetColor();
                return;
            }

            Console.WriteLine("Users:");
            for (int i = 0; i < lines.Length; i++)
            {
                try
                {
                    var user = System.Text.Json.JsonSerializer.Deserialize<MedicalLoginSystemConsole.Models.User>(lines[i]);
                    if (user != null)
                        Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"{i + 1}. {user.Email} - {user.Name}");
                    Console.ResetColor();
                }
                catch
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"{i + 1}. [Invalid user data]");
                    Console.ResetColor();
                }
            }
        }
    
 
        static void AddServices()
        {
            var services = LoadServices();

            int newId = services.Any() ? services.Max(s => s.Id) + 1 : 1;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the name of the service: ");
            Console.ResetColor();
            string name = Console.ReadLine()?.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Service name cannot be empty.");
                Console.ResetColor();
                return;
            }
            if (services.Any(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" This service already exists.");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the description: ");
            Console.ResetColor();
            string description = Console.ReadLine()?.Trim() ?? "";

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the price: ");
            Console.ResetColor();
            if (!decimal.TryParse(Console.ReadLine(), out decimal price) || price < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid price.");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the stock: ");
            Console.ResetColor();
            if (!int.TryParse(Console.ReadLine(), out int stock) || stock < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid stock.");
                Console.ResetColor();
                return;
            }

            var service = new Service
            {
                Id = newId,
                Name = name,
                Description = description,
                Price = price,
                
            };
            services.Add(service);
            SaveServices(services);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($" Service {name} added.");
            Console.ResetColor();
        }
        static void ChangePriceOfService()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the name of the service you want to change: ");
            Console.ResetColor();
            string serviceName = Console.ReadLine()?.Trim();
            if (string.IsNullOrWhiteSpace(serviceName) || !services.ContainsKey(serviceName))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Service not found.");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the new price: ");
            Console.ResetColor();
            if (!int.TryParse(Console.ReadLine(), out int newPrice) || newPrice < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid price");
                Console.ResetColor();
                return;
            }
            services[serviceName] = newPrice;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($" Service {serviceName} price has changed to {newPrice}.");
            Console.ResetColor();
            try
            {
                File.WriteAllLines("Services.txt", services.Select(s => $"{s.Key},{s.Value}"));
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($" Failed to update service: {ex.Message}");
                Console.ResetColor();
            }
        }
        static void RemoveService()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the name of the service you want to remove: ");
            Console.ResetColor();

        }
        public static void ShowServices(bool isUser = false, Cart userCart = null)
        {
            var services = LoadServices();
            foreach (var s in services)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($" ID: {s.Id} | Name: {s.Name} | Desc: {s.Description} | Price: {s.Price} | Available: {s.Availability}");
                Console.ResetColor();
            }

            if (isUser && userCart != null)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write(" Enter the ID of the service to add to cart (or press Enter to skip): ");
                Console.ResetColor();
                var input = Console.ReadLine();
                if (int.TryParse(input, out int serviceId))
                {
                    var selectedService = services.FirstOrDefault(s => s.Id == serviceId);
                    if (selectedService != null)
                    {
                        userCart.AddToCart(selectedService);
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($" {selectedService.Name} added to cart.");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(" Service not found.");
                        Console.ResetColor();
                    }
                }
            }
        }
        static void FidPointsMan()
        {

        }
    }
}

