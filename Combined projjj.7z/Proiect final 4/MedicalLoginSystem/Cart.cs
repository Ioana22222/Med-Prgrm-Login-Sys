﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography.X509Certificates;
using Twilio.Rest.Numbers.V2.RegulatoryCompliance.Bundle;
using System.IO;
using MedicalLoginSystemConsole.Models;

namespace MedicalLoginSystem
{
    public class Cart
    {
        private static List<Service> services = new List<Service>();
        
        public int Id { get; set; }
        //public static decimal totalPrice = services.Sum(service => service.Price);
        
        public decimal TotalPrice => services.Sum(s => s.Price);

        public void AddToCart(Service service)
        {
            services.Add(service);
            SaveCart();
        }

        public void SaveCart(string filePath = "cart.txt")
        {
            List<string> lines = new List<string>();
            lines.Add($"{Id}");
            File.WriteAllLines(filePath, lines);
            File.WriteAllLines(filePath, services.Select(s => $"{s.Id}|{s.Name}|{s.Description}|{s.Price}|{s.Availability}"));
            lines.Clear();
            lines.Add("");
            File.WriteAllLines(filePath, lines);
        }

        public void LoadCart(string filePath = "cart.txt")
        {
            services.Clear();
            Id = User.currUser;
            if (!File.Exists(filePath)) return;
            foreach (var line in File.ReadAllLines(filePath))
            {
                try
                {
                    bool found = false;
                    if (line == Id.ToString())
                        found = true;
                    if (found && (line != Id.ToString() && line != " "))
                        services.Add(Service.FromString(line));
                    if (found && line == "")
                        break;
                }
                catch { }
            }
        }

        public static void ShowCart()
        {
            if (services.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Your cart is empty. ");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(" Your cart contains: \n");

            Console.ResetColor();

            int i = 1;
            foreach (var service in services)
            {
                Console.WriteLine($"{i++}. {service.Name} - {service.Price:C}");
            }

            Console.ResetColor();
            Console.WriteLine("\n Would you like to proceed with your order? ");

            Console.Write("(");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Y");
            Console.ResetColor();
            Console.Write("/");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("N");
            Console.ResetColor();
            Console.Write("): ");

            switch (Console.ReadLine()?.ToUpper())
            {
                case "Y":

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" Proceeding with your order...");
                    Console.ResetColor();

                    totalPrice = Discounts.ApplyFidelityPointsDiscount(totalPrice);

                    break;

                case "N":
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Order cancelled.");
                    Console.ResetColor();
                    break;

                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Invalid choice. Returning to main menu.");
                    Console.ResetColor();
                    Thread.Sleep(2000);
                    Console.Clear();
                    break;
            }
        }
    }
}