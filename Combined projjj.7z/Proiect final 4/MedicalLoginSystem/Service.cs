using System;

namespace MedicalLoginSystem
{
    public class Service
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool Availability { get; set; }
        public override string ToString()
        {
            //return $"{Name} - {Price:C}";
            return $"{Id},{Name},{Description},{Price},{Availability}";
        }
        public static Service FromString(string line)
        {
            
            var parts = line.Split('|');
            return new Service
            {
                Id = int.Parse(parts[0]),
                Name = parts[1],
                Description = parts[2],
                Price = decimal.TryParse(parts[3], out var price) ? price : 0,
                Availability = bool.Parse(parts[4])
            };
        }
    }
}
