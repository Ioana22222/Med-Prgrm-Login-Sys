﻿using MedicalLoginSystemConsole.Models;
using System;

namespace MedicalLoginSystem.UIHelper
{
    public static class ConsoleUI
    {
        public static void DrawBalanceTopRight(Bank bank)
        {
            int origX = Console.CursorLeft;
            int origY = Console.CursorTop;

            string text = bank.ToString();
            int x = Console.WindowWidth - text.Length - 1;

            Console.SetCursorPosition(x, 0);
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(text);
            Console.ResetColor();

            Console.SetCursorPosition(origX, origY); 
        } 
    }
}
//nu bagati in seama :) 