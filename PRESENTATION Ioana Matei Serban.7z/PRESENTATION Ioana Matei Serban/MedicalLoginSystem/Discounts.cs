﻿using MedicalLoginSystem;
using MedicalLoginSystemConsole.Models;


namespace Proiect
{
    public class Discounts
    {
        public static decimal ApplyFidelityPointsDiscount(decimal total)
        {
            int points = FidelityManager.GetPoints(User.currUser);

            if (points <= 0) return total;

            decimal discount = points * 0.1m; 
            if (discount > total) discount = total;

            FidelityManager.SetPoints(User.currUser, points - (int)(discount / 0.1m));

            return total - discount;
        }

    }
}
