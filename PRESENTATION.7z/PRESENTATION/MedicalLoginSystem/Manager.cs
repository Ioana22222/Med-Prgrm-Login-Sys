﻿using MedicalLoginSystem; 
using MedicalLoginSystemConsole.Services; 
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using MedicalLoginSystem;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace Proiect
{
    internal class Manager
    {
        public static List<MedicalLoginSystemConsole.Models.User> users = new List<MedicalLoginSystemConsole.Models.User>();
        public static List<Service> services = LoadServices();
        //static Dictionary<string, int> services = new Dictionary<string, int>();
        static List<Service> LoadServices()
        {
            var list = new List<Service>();
            if (!File.Exists("Services.txt")) return list;
            foreach (var line in File.ReadAllLines("Services.txt"))
            {
                try {

                    list.Add(JsonSerializer.Deserialize<Service>(line));
                }
                catch { }
            }
            return list;
        }

        static void SaveServices()
        {
            File.WriteAllLines("Services.txt", new string[] { "" });
            foreach (var service in services)
            {   
                string line = JsonSerializer.Serialize(service);
                File.AppendAllLines("Services.txt", new[] { line });
            }
        }


        public static void ShowManagerMenu()
        {

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n ============= Manager Menu ============= ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" 1 - Add users: ");
            Console.WriteLine(" 2 - Remove users: ");
            Console.WriteLine(" 3 - List users: ");
            Console.WriteLine(" 4 - Add Services: ");
            Console.WriteLine(" 5 - Change price of a service: ");
            Console.WriteLine(" 6 - Remove service: ");
            Console.WriteLine(" 7 - Show services: ");
            Console.WriteLine("\n 0 - Go back Register/Login menu\n");
            Console.ResetColor();
        }
        public static void ChooseManagerOptions()
        {
            while (true)
            {
            options:
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n Select your option: \n");
                Console.ResetColor();
                string opt = Console.ReadLine();
                Console.Write("\n");
                switch (opt)
                {
                    case "1":
                        AddUsers();
                        break;

                    case "2":
                        RemoveUsers();
                        break;

                    case "3":
                        ListUsers();
                        break;

                    case "4":
                        AddServices();
                        break;

                    case "5":
                        ChangePriceOfService();
                        break;

                    case "6":
                        RemoveService();
                        break;

                    case "7":
                        ShowServices(false, new Cart());
                        break;

                    case "0":
                        Console.Clear();
                        UserManager.StartProgram();
                        break;

                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(" Choose 1-7");
                        Console.ResetColor();
                        goto options;


                }
                Console.WriteLine("\n Press any key to return to the Admin Menu...");
                Console.ReadKey();
                Thread.Sleep(2000);
                Console.Clear();

            }
        }
            static void AddUsers()
            {
                UserManager.Register();
            }

            static void RemoveUsers()
            {
                var filePath = "Users.txt";
                if (!File.Exists(filePath))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" No users found.");
                    Console.ResetColor();
                    return;
                }

                var lines = File.ReadAllLines(filePath).ToList();
                if (lines.Count == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" No users to remove.");
                    Console.ResetColor();
                    return;
                }


                Console.WriteLine(" Users:");
                for (int i = 0; i < lines.Count; i++)
                {
                    try
                    {
                        var user = System.Text.Json.JsonSerializer.Deserialize<MedicalLoginSystemConsole.Models.User>(lines[i]);
                        if (user != null)
                            Console.WriteLine($"{i + 1}. {user.Email} - {user.Name}");
                    }
                    catch
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"{i + 1}. [Invalid user data]");
                        Console.ResetColor();
                    }
                }

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write(" Enter the number of the user to remove: "); Console.ResetColor();
                if (int.TryParse(Console.ReadLine(), out int idx) && idx > 0 && idx <= lines.Count)
                {
                    lines.RemoveAt(idx - 1);
                    File.WriteAllLines(filePath, lines);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" User removed.");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Invalid selection.");
                    Console.ResetColor();
                }
            }
        

        public static void LoadUsers()
        {
            var filePath = "Users.txt";
            var lines = File.ReadAllLines(filePath);
            for (int i = 0; i < lines.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(lines[i])) continue;
                var user = System.Text.Json.JsonSerializer.Deserialize<MedicalLoginSystemConsole.Models.User>(lines[i]);
                users.Add(user);
            }
        }

        static void ListUsers()
        {
            var filePath = "Users.txt";
            if (!File.Exists(filePath))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" No users found.");
                Console.ResetColor();
                return;
            }

            var lines = File.ReadAllLines(filePath);
            if (lines.Length == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" No users to display.");
                Console.ResetColor();
                return;
            }

            Console.WriteLine("Users:");
            for (int i = 0; i < lines.Length; i++)
            {
                try
                {
                    var user = System.Text.Json.JsonSerializer.Deserialize<MedicalLoginSystemConsole.Models.User>(lines[i]);
                    if (user != null)
                        Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"{i + 1}. {user.Email} - {user.Name}");
                    Console.ResetColor();
                }
                catch
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"{i + 1}. [Invalid user data]");
                    Console.ResetColor();
                }
            }
        }


        static void AddServices()
        {

            int newId = services.Any() ? services.Max(s => s.Id) + 1 : 1;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the name of the service: ");
            Console.ResetColor();
            string name = Console.ReadLine()?.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Service name cannot be empty.");
                Console.ResetColor();
                return;
            }
            if (services.Any(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" This service already exists.");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the description: ");
            Console.ResetColor();
            string description = Console.ReadLine()?.Trim() ?? "";

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the price: ");
            Console.ResetColor();
            if (!decimal.TryParse(Console.ReadLine(), out decimal price) || price < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid price.");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the number of available slots: ");
            Console.ResetColor();
            if (!int.TryParse(Console.ReadLine(), out int stock) || stock < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid stock.");
                Console.ResetColor();
                return;
            }

            var service = new Service
            {
                Id = newId,
                Name = name,
                Description = description,
                Price = price,
                AvailableSlots=stock,
            };
            services.Add(service);
            SaveServices();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($" Service {name} added.");
            Console.ResetColor();
        }
        static void ChangePriceOfService()
        {
            var services = LoadServices();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Enter the ID of the service you want to change: ");
            Console.ResetColor();

            if (!int.TryParse(Console.ReadLine(), out int serviceID))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" ID invalid.");
                Console.ResetColor();
                return;
            }

            var service = services.FirstOrDefault(s => s.Id == serviceID);

            if (service == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Service not found.");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($" Current price for {service.Name} is {service.Price}. Enter the new price: ");
            Console.ResetColor();

            if (!decimal.TryParse(Console.ReadLine(), out decimal newPrice) || newPrice < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid price.");
                Console.ResetColor();
                return;
            }

            service.Price = newPrice;

            try
            {
                File.WriteAllLines("Services.txt", services.Select(s => JsonSerializer.Serialize(s)));
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($" Price for service '{service.Name}' changed to {newPrice}.");
                Console.ResetColor();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($" Failed to save services: {ex.Message}");
                Console.ResetColor();
            }
        }
     
        static void RemoveService()
        {
            var services = LoadServices();

            if (services.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" No services available to remove.");
                Console.ResetColor();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" Available services:");
            foreach (var s in services)
            {
                Console.WriteLine($" ID: {s.Id} | Name: {s.Name} | Price: {s.Price} | Stock: {s.AvailableSlots}");
            }
            Console.Write(" Enter the ID of the service you want to remove: ");
            Console.ResetColor();

            if (int.TryParse(Console.ReadLine(), out int serviceId))
            {
                var serviceToRemove = services.FirstOrDefault(s => s.Id == serviceId);
                if (serviceToRemove != null)
                {
                    services.Remove(serviceToRemove);
                    
                    try
                    {
                        File.WriteAllLines("Services.txt", services.Select(s => JsonSerializer.Serialize(s)));
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($" Service '{serviceToRemove.Name}' removed successfully.");
                        Console.ResetColor();
                    }
                    catch (Exception ex)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" Error saving services: {ex.Message}");
                        Console.ResetColor();
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Service with this ID was not found.");
                    Console.ResetColor();
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid input for service ID.");
                Console.ResetColor();
            }
        }

        public static void ShowServices(bool isUser, Cart userCart)
        {
            var services = LoadServices();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n Filters services by: \n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" 1 - Ascending Price");
            Console.WriteLine(" 2 - Descending Price");
            Console.WriteLine(" 3 - Price Range:");
            Console.WriteLine(" 4 - No filters \n");
            Console.ResetColor();

            string filterOption = Console.ReadLine();
            Console.Write("\n");

            switch (filterOption)
            {
                case "1":
                    services = services.OrderBy(s => s.Price).ToList();
                    break;
                case "2":
                    services = services.OrderByDescending(s => s.Price).ToList();
                    break;
                case "3":
                    Console.Write(" Enter min price: ");
                    if (!decimal.TryParse(Console.ReadLine(), out decimal minPrice))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(" Invalid min price. Showing all services.");
                        Console.ResetColor();
                        break;
                    }
                    Console.Write(" Enter max price: ");
                    if (!decimal.TryParse(Console.ReadLine(), out decimal maxPrice))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(" Invalid max price. Showing all services.");
                        Console.ResetColor();
                        break;
                    }
                    if (minPrice > maxPrice)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(" Minimum price can't be higher than maximum price, showing all services.");
                        Console.ResetColor();
                        break;
                    }
                    services = services.Where(s => s.Price >= minPrice && s.Price <= maxPrice).ToList();
                    break;
                case "4":
                    
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine(" Invalid option.");
                    Console.ResetColor();
                    break;
            }

            if (services.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(" No services that meets these criteria.");
                Console.ResetColor();
                return;
            }

            foreach (var s in services)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($" ID: {s.Id} | Name: {s.Name} | Desc: {s.Description} | Price: {s.Price} | Available: {s.AvailableSlots}");
                Console.ResetColor();
            }

            if (isUser && userCart != null)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("\n Enter the ID of the service to add to cart (or press 0 to skip): \n\n");
                Console.ResetColor();
                var input = Console.ReadLine();
                if (int.TryParse(input, out int serviceId))
                {
                    if (serviceId != 0)
                    {
                        var selectedService = services.FirstOrDefault(s => s.Id == serviceId);
                        if (selectedService != null)
                        {
                            if (selectedService.AvailableSlots > 0)
                            {
                                userCart.AddService(selectedService);
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine($"\n {selectedService.Name} added to cart. \n");
                                Thread.Sleep(2200);
                                Console.ResetColor();
                                Console.Clear();
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine(" No more available slots.");
                                Console.ResetColor();
                            }
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine(" Service not found.");
                            Console.ResetColor();
                        }
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine(" No service added to cart.");
                        Console.ResetColor();
                        Thread.Sleep(2000);
                        Console.Clear();
                        UserManager.Spinner("\n  Loading ", 2200);
                        Console.Clear();
                        UserManager.UserMenu(userCart);
                    }
                }
            }
        }

    }
}

  
    
   



