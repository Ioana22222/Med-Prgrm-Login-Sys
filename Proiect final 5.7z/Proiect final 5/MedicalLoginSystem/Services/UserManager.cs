﻿using MedicalLoginSystem;
using MedicalLoginSystem.UIHelper;
using MedicalLoginSystemConsole.Models; 
using Proiect;
using System.Reflection.Metadata.Ecma335;
using System.Text.Json;
using System.Text.RegularExpressions;


namespace MedicalLoginSystemConsole.Services
{
    public class UserManager

    {
        public static void Spinner(string message, int duration)
        {
            Console.Write(message);
            char[] spinner = {  '|', '/', '-', '\\' };
            var end = DateTime.Now.AddMilliseconds(duration);
            int i = 0;

            while (DateTime.Now < end)
            {
                Console.Write($"{spinner[i++ % spinner.Length]}\b");
                Thread.Sleep(100);
            }
            Console.Write(" \b ");
        }

        public static Bank bank = new Bank(10000m);


        private static readonly string filePath = "Users.txt";
        static bool showTitle = true;
        string pathu = "Users.txt";
        private static Cart userCart;

        public static void StartProgram()
        {
            while (true)
            {
                ConsoleUI.DrawBalanceTopRight(bank);
                Manager.LoadUsers();
                User.totalUsers = Manager.users.Count;

                if (showTitle)
                {
                    Console.Clear();
                    Spinner("\n  Loading ", 2200);
                    Console.Clear();

                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n ======================== Medistra – Login & Registration ========================\n");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine(" A program designed for the authentification of patients and administrators.");
                    Console.WriteLine(" All data is stored locally and verified via an SMS code.\n");
                    Console.ResetColor();
                    showTitle = false;
                }
                else Console.Clear();

                Console.WriteLine("\n 1. Register");
                Console.WriteLine(" 2. Login");
                Console.WriteLine(" 3. Exit");
                Console.WriteLine("\n");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write(" Choose an option: ");
                Console.ResetColor();
                var option = Console.ReadLine();

                switch (option)
                {
                    case "1":
                        Console.Clear();
                        Spinner("\n  Loading ", 2000);
                        Console.Clear();
                        UserManager.Register();
                        showTitle = true;
                        break;

                    case "2":
                        Console.Clear();
                        Spinner("\n  Loading ", 2000);
                        Console.Clear();
                        UserManager.Login();
                        showTitle = true;
                        break;

                    case "3":
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("\n Thank you for using our program!");
                        Console.ResetColor();
                        return;

                    default:
                        Console.WriteLine(" Invalid option. Please try again.");
                        Thread.Sleep(1500);
                        Console.Clear();
                        break;
                }
            }
        }
        public static void UserMenu(Cart userCart)
        {

            userCart = new Cart();

            while(true) 
            {

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n ============= Medistra – User Menu ============= \n");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" 1 - List of services ");
            Console.WriteLine(" 2 - View Cart");
            Console.WriteLine(" 3 - View fidelity points:");
            Console.WriteLine(" 4 - Checkout");
            Console.WriteLine("\n 0 - Go back to Login/Registration menu");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\n Choose an option: ");
            var option = Console.ReadLine();
                switch (option)
                {
                    case "1":
                        Manager.ShowServices(isUser: true, userCart: userCart);
                        break;

                    case "2":
                        Cart.ShowCart();
                        break;

                    case "3":
                        Console.WriteLine($" You have {Manager.users[User.currUser].FidelityPoints} fidelity points.");
                        Console.WriteLine("\n Press 0 to return to the main menu...");

                        while (Console.ReadKey(true).KeyChar != '0')
                        {
                            // Wait until '0' is pressed
                        }
                        Console.Clear();
                        Spinner("\n  Loading ", 2000);
                        break;

                    case "4":
                        Console.Clear();
                        Spinner("\n  Processing payment ", 2000);
                        Console.Clear();
                        Console.WriteLine(" Payment successful!");
                        showTitle = true;
                        break;

                    case "0":
                        Console.ResetColor();
                        Console.Clear();
                        Spinner("\n  Loading ", 2000);
                        Console.Clear();
                        return;

                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid option. Please try again.");
                        Console.ResetColor();
                        break;

                }
            }
        }
        public static void Register()
        {
            string email, password, phone, role;
            string surname, name, fullName;

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("\n Surname: ");
                Console.ResetColor();
                surname = Console.ReadLine()!;
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write(" Name: ");
                Console.ResetColor();
                name = Console.ReadLine()!;
                fullName = $"{surname} {name}";

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write(" Your full name is: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(fullName);
                Console.ResetColor();
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write(" Is this correct? ");
                Console.ResetColor();
                Console.Write("(");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Y");
                Console.ResetColor();
                Console.Write("/");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("N");
                Console.ResetColor();
                Console.Write("): ");

                var confirm = Console.ReadLine()!.Trim().ToLower();

                if (confirm == "y" || confirm == "Y") break;

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Please reenter your information.\n");
                Console.ResetColor();
            }

        email_verification:

        

            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.Write("\n "); 
            Console.Write("\n Email: ");
            Console.ResetColor();
            email = Console.ReadLine()!;

            bool IsEmailValid(string email)
            {
                string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
                return Regex.IsMatch(email, pattern);
            }

            if (!IsEmailValid(email))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($" Invalid email format: {email}");
                Console.WriteLine(" Please try again.");
                Console.ResetColor();
                Thread.Sleep(2100);
                Console.Clear();
                goto email_verification;
            }
            else
            {
                
            }


        //password verification

        password:

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("\n ");
            Console.Write("\n Password: ");
            Console.ResetColor();
            password = Console.ReadLine()!;

            bool IsValidPassword(string password)
            {
                // At least one digit, one letter, one special character, and min 6 characters total

                string pattern = @"^(?=.*\d)(?=.*[A-Za-z])(?=.*[@$!%?&#&])[A-Za-z\d@$!%?&]{6,}$";
                return Regex.IsMatch(password, pattern);
            }

            if (!IsValidPassword(password))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Password must be at least 6 characters long and include at least one number, one letter and one special character.");
                Console.ResetColor();
                Thread.Sleep(2200);
                goto password;
            }

            //Admin role SMS requirement

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(" Role (User/Admin) -> Please note that for the role ~Admin~ an SMS code is required: ");
            Console.ResetColor();

            role = Console.ReadLine()!;

            if (UserManager.EmailExists(email))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" This email already exists.");
                Console.ResetColor();
                //Console.WriteLine("\n Press 0 to return to the main menu...");

                //while (Console.ReadKey(true).KeyChar != '0')
                //{
                //    // Wait until '0' is pressed
                //}
                //Console.Clear();
                //Spinner("\n  Loading ", 2000);
                Thread.Sleep(2000);
                Console.Clear();
                goto email_verification;
            }
            if (role == "Admin" || role == "admin")
            {
            phone_verif:
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write(" Phone number (+407...): ");
                Console.ResetColor();
                phone = Console.ReadLine()!;

                try
                {
                    if (string.IsNullOrWhiteSpace(phone) || !phone.StartsWith("+407"))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(" Invalid phone number format.");
                        Console.ResetColor();
                        Thread.Sleep(2000);
                        Console.Clear();
                        return;
                    }
                    SmsService.SendCode(phone);
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.Write(" Please enter the code received via SMS: ");
                    Console.ResetColor();
                    string code = Console.ReadLine()!;

                    if (code != SmsService.LatestCode)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(" Incorrect code. Failed to Register.");
                        Console.ResetColor();
                        //Console.WriteLine("\n Press 0 to return to the main menu...");

                        //while (Console.ReadKey(true).KeyChar != '0')
                        //{
                        //    // Wait until '0' is pressed
                        //}
                        //Console.Clear();
                        //Spinner("\n  Loading ", 2000);
                        Thread.Sleep(2000);
                        Console.Clear();
                        goto phone_verif;
                    }

                    var user = new User(email, fullName, password, role, phone);
                    UserManager.SaveUser(user);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($" Account created successfully! Welcome, {fullName}");
                    Console.ResetColor();

                    Console.WriteLine("\n Press 0 to return to the main menu...");
                    while (Console.ReadKey(true).KeyChar != '0')
                    {
                        // Wait until '0' is pressed
                    }
                    Console.Clear();
                    Spinner("\n  Loading ", 2000);
                    Console.Clear();
                    return;
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Error -> SMS could not be sent: " + ex.Message);
                    Console.ResetColor();
                    Console.WriteLine("\n Press 0 to return to the main menu...");
                    while (Console.ReadKey(true).KeyChar != '0')
                    {
                        // Wait until '0' is pressed
                    }
                    Console.Clear();
                    Spinner("\n  Loading ", 2000);
                    Console.Clear();
                }
            }
            else if (role == "User" || role == "user")
            {
                var user = new User(email, fullName, password, "User", null);
                UserManager.SaveUser(user);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($" Account created successfully! Welcome, {fullName}");
                Console.ResetColor();
                Thread.Sleep(2000);
                Console.Clear();
                Spinner("\n  Loading ", 2000);
                Console.Clear();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid data. Please enter one of the two options.");
                Console.ResetColor();
                Thread.Sleep(2000);
                Console.Clear();
            }
        }
        public static void Login()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(" Email: ");
            Console.ResetColor();
            string email = Console.ReadLine()!;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(" Password: ");
            Console.ResetColor();
            string password = Console.ReadLine()!;

            var user = UserManager.ValidateLogin(email, password);
            if (user == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Incorrect authentification data.");
                Console.ResetColor();
                Console.WriteLine("\n Press 0 to return to the main menu...");
                if (Console.ReadKey(true).KeyChar != '0')
                {

                }
                else
                {
                    Console.Clear();
                    Spinner("\n  Loading ", 2000);
                    Console.Clear();
                    return;
                }
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n Hello, {user.Name}! You are logged in as {user.Role}.");
            Console.ResetColor();

            if (user.Role.ToLower() == "admin" || user.Role.ToLower() == "Admin")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(" - Accessing the admin panel...\n");
                Console.ResetColor();
                Thread.Sleep(2100);
                Console.Clear();
                Spinner("\n  Loading ", 2000);
                Console.Clear();
                Manager.ShowManagerMenu();
                Manager.ChooseManagerOptions();
            }
            else if (user.Role.ToLower() == "user" || user.Role.ToLower() == "User")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(" - Accessing the user panel...\n");
                Console.ResetColor();
                Thread.Sleep(2100);
                Console.Clear();
                Spinner("\n  Loading ", 2000);
                Console.Clear();
                UserMenu(userCart);
            }

            Console.ResetColor();
            Console.WriteLine("\n Press 0 to return to the main menu...");
            while (Console.ReadKey(true).KeyChar != '0')
            {
                // Wait until '0' is pressed
            }
            Console.Clear();
            Spinner("\n  Loading ", 2000);
            Console.Clear();

        }

        private static void UserMenu(object userCart)
        {
            throw new NotImplementedException();
        }

        public static void SaveUser(User user)
        {
            string json = JsonSerializer.Serialize(user);
            File.AppendAllText(filePath, json + Environment.NewLine);
        }

        public static bool EmailExists(string email)
        {
            if (!File.Exists(filePath)) return false;

            var lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                try
                {
                    var user = JsonSerializer.Deserialize<User>(line);
                    if (user != null && user.Email == email)
                        return true;
                }
                catch
                {
                    
                }
            }

            return false;
        }

        public static User? ValidateLogin(string email, string password)
        {
            if (!File.Exists(filePath)) return null;

            var lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                try
                {
                    var user = JsonSerializer.Deserialize<User>(line);
                    if (user != null && user.Email == email && user.Password == password)
                    {
                        User.currUser = user.Idu;
                        return user;
                    }
                }
                catch
                {

                }
            }

            return null;
        }
    }
}
