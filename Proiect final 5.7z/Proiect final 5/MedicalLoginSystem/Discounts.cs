﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

using System.Security.Cryptography;

namespace MedicalLoginSystem
{
    internal class Discounts
    {

        public static decimal ApplyFidelityPointsDiscount(decimal totalPrice)
        {
            if (Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints > 100)
            {
                Console.WriteLine($" You have {Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints} fidelity points.");
                Console.Write(" Would you like to use them for a discount? (Y/N): ");
                string usePoints = Console.ReadLine()?.Trim().ToUpper();

                if (usePoints == "Y")
                {
                    decimal discount = 0m;
                    if (Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints >= 100 && Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints <= 299)
                        discount = 0.10m;
                    else if (Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints >= 300 && Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints <= 499)
                        discount = 0.20m;
                    else if (Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints >= 500)
                        discount = 0.30m;

                    if (discount > 0)
                    {
                        decimal discountAmount = totalPrice * discount;
                        totalPrice -= discountAmount;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($" Your total after applying fidelity points is: {totalPrice:C}");
                        Console.ResetColor();
                        Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints = 0;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine(" Fidelity points not used.");
                        Console.ResetColor();
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($" Your total is: {totalPrice:C}");
                    Console.ResetColor();
                }
                Proiect.Manager.users[MedicalLoginSystemConsole.Models.User.currUser].FidelityPoints = 0;
            }
            return totalPrice;
        }
    }
}