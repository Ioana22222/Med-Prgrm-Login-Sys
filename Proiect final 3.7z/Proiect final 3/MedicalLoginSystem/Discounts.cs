﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

using System.Security.Cryptography;

namespace MedicalLoginSystem
{
    internal class Discounts
    {
        private readonly RandomNumberGenerator rng = RandomNumberGenerator.Create();

        public int GetRandomNumber0To100()
        {
            byte[] data = new byte[4];
            rng.GetBytes(data);
            int value = BitConverter.ToInt32(data, 0) & int.MaxValue;
            return value % 101;
        }
        public int DiscountCode;
        public static decimal ApplyDiscount(decimal price, string discountCode)
        {
            if (string.IsNullOrEmpty(discountCode))
                return price;

            if (discountCode.Equals("DISCOUNT10", StringComparison.OrdinalIgnoreCase))
            {
                return price * 0.90m; // 10% discount
                discountCode = "";
            }
            else if (discountCode.Equals("DISCOUNT20", StringComparison.OrdinalIgnoreCase))
            {
                return price * 0.80m; // 20% discount
            }
            else if (discountCode.Equals("DISCOUNT30", StringComparison.OrdinalIgnoreCase))
            {
                return price * 0.100m; // 30% discount
            }
            return price; 
        }

        public decimal ApplyRandomDiscount(decimal price, string discountCode)
        {
            int randomNumber = GetRandomNumber0To100();
            if (randomNumber > 0)
            {
                return ApplyDiscount(price, discountCode);
            }
            else
            {
                return price;
            }
        }
    }
}
