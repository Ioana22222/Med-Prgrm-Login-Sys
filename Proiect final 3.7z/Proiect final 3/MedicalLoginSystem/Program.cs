﻿using System;
using MedicalLoginSystemConsole.Models;
using MedicalLoginSystemConsole.Services;
using Proiect;

namespace MedicalLoginSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            UserManager.StartProgram();
        }
    }
}



