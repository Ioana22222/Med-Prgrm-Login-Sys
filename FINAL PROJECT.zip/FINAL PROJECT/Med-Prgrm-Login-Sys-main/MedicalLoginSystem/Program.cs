﻿using MedicalLoginSystemConsole.Models;
using MedicalLoginSystemConsole.Services;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

bool showTitle = true;

while (true)
{

    if (showTitle)
    {
        Console.WriteLine("\n");
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(" ==================== Medistra – Login & Registration ====================");
        Console.WriteLine("\n");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("--------------------------------------------------------------------------");
        Console.ResetColor();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(" A program designed for the authentication of patients and administrators.");
        Console.WriteLine(" All data is stored locally and verified via an SMS code.");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("--------------------------------------------------------------------------");
        Console.ResetColor();
   
        showTitle = false;

    } else Console.Clear();

    Console.WriteLine("\n");
    Console.WriteLine("\n 1. Register");
    Console.WriteLine(" 2. Login");
    Console.WriteLine(" 3. Exit");
    Console.WriteLine("\n");
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.Write(" Choose an option: ");
    Console.ResetColor();
    var option = Console.ReadLine();

    switch (option)
    {
        case "1":
            Console.Clear();
            Register();
            showTitle = true;
            break;
        case "2":
            Console.Clear();
            Login();
            showTitle = true;
            break;
        case "3":
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(" Thank you for using our program!");
            Console.ResetColor();
            return;
        default:
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(" Invalid option. Please try again.");
            Console.ResetColor();
            Thread.Sleep(1500);
            Console.Clear();
            break;
    }
}

void Register()
{
    string email, password, phone, role;
    string surname, name, fullName;

    while (true)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write("\n Surname: ");
        Console.ResetColor();
        surname = Console.ReadLine()!;
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write(" Name: ");
        Console.ResetColor();
        name = Console.ReadLine()!;
        fullName = $"{surname} {name}";

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write(" Your full name is: ");
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write(fullName);
        Console.ResetColor();
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write(" Is this correct? "); 
        Console.ResetColor();
        Console.Write("(");
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write("Y");
        Console.ResetColor();
        Console.Write("/");
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Write("N");
        Console.ResetColor();
        Console.Write("): ");

        var confirm = Console.ReadLine()!.Trim().ToLower();

        if (confirm == "y" || confirm == "Y") break;

        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(" Please reenter your information.\n");
        Console.ResetColor();
    }

//email verification

email:

    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.Write(" Email: ");
    Console.ResetColor();
    email = Console.ReadLine()!;

    bool IsEmailValid(string email)
    {
        string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
        return Regex.IsMatch(email, pattern);
    }

    if (!IsEmailValid(email))
    {  
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($" Invalid email format: {email}");
            Console.WriteLine(" Please try again.");
            Console.ResetColor();
            Thread.Sleep(2100);
            Console.Clear();
    }
      else
      {
         goto email;
      }


//password verification

password:

    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.Write(" Password: ");
    Console.ResetColor();
    password = Console.ReadLine()!;

    bool IsValidPassword(string password)
    {
    
        // At least one digit, one letter, one special character, and min 6 characters total

        string pattern = @"^(?=.*\d)(?=.*[A-Za-z])(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{6,}$";
        return Regex.IsMatch(password, pattern);
    }

    if (!IsValidPassword(password))
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(" Password must be at least 6 characters long and include at least one number, one letter and one special character.");
        Console.ResetColor();
        Thread.Sleep(2200);
        goto password;
    }

    //Admin role SMS requirement

    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.Write(" Role (User/Admin) -> Please note that for the role ~Admin~ an SMS code is required: ");
    Console.ResetColor();

    role = Console.ReadLine()!;

    if (UserManager.EmailExists(email))
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(" This email already exists.");
        Console.ResetColor();
        Console.WriteLine("\n Press 0 to return to the main menu...");
        
        while (Console.ReadKey(true).KeyChar != '0')
        {
            // Wait until '0' is pressed
        }
        Console.Clear();
        return;
    }
    if (role == "Admin" || role == "admin")
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.Write(" Phone number (+407...): ");
        Console.ResetColor();
        phone = Console.ReadLine()!;

        try
        {
            if (string.IsNullOrWhiteSpace(phone) || !phone.StartsWith("+407"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Invalid phone number format.");
                Console.ResetColor();
                Thread.Sleep(2000);
                Console.Clear();
                return;
            }
            SmsService.SendCode(phone);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(" Please enter the code received via SMS: ");
            Console.ResetColor();
            string code = Console.ReadLine()!;

            if (code != SmsService.LatestCode)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(" Incorrect code. Failed to Register.");
                Console.ResetColor();
                Console.WriteLine("\n Press 0 to return to the main menu...");
                
                while (Console.ReadKey(true).KeyChar != '0')
                {
                    // Wait until '0' is pressed
                }
                Console.Clear();
                return;
            }

            var user = new User(email, fullName, password, role, phone);
            UserManager.SaveUser(user);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($" Account created successfully! Welcome, {fullName}");
            Console.ResetColor();

            Console.WriteLine("\n Press 0 to return to the main menu...");
            while (Console.ReadKey(true).KeyChar != '0')
            {
                // Wait until '0' is pressed
            }
            Console.Clear();

        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(" Error -> SMS could not be sent: " + ex.Message);
            Console.ResetColor();
            Console.WriteLine("\n Press 0 to return to the main menu...");
            while (Console.ReadKey(true).KeyChar != '0')
            {
                // Wait until '0' is pressed
            }
            Console.Clear();
        }
    }
    else if (role == "User" || role == "user")
    {
        var user = new User(email, fullName, password, "User", null);
        UserManager.SaveUser(user);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($" Account created successfully! Welcome, {fullName}");
        Console.ResetColor();
        Thread.Sleep(2000);
        Console.Clear();
    }
    else
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(" Invalid data. Please enter one of the two options.");
        Console.ResetColor();
        Thread.Sleep(2000);
        Console.Clear();
    }
}
void Login()
{
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.Write(" Email: ");
    Console.ResetColor();
    string email = Console.ReadLine()!;
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.Write(" Password: ");
    Console.ResetColor();
    string password = Console.ReadLine()!;

    var user = UserManager.ValidateLogin(email, password);
    if (user == null)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(" Incorrect authentica123tion data.");
        Console.ResetColor();
        return;
    }

    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine($"\n Hello, {user.Name}! You are logged in as {user.Role}.");
    Console.ResetColor();

    if (user.Role.ToLower() == "admin" || user.Role.ToLower() == "Admin")
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(" - Accessing the admin panel...");
        Console.ResetColor();
    }
    else if (user.Role.ToLower() == "user" || user.Role.ToLower() == "User")
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(" - Accessing the user panel...");
        Console.ResetColor();
    }

    Console.ResetColor();
    Console.WriteLine("\n Press 0 to return to the main menu...");
    while (Console.ReadKey(true).KeyChar != '0')
    {
        // Wait until '0' is pressed
    }
    Console.Clear();

}